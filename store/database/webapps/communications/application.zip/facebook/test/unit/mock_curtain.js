'use strict';

/* exported MockCurtain */

var MockCurtain = {
  show: function() {
    return {
      update: function() {

      },
      setTotal: function() {

      },
      getValue: function() {

      }
    };
  },
  hide: function() {

  },
  hideMenu: function(){}
};
