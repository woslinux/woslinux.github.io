/* exported MockConferenceGroupUI */

'use strict';

var MockConferenceGroupUI = {
  addCall: function() {},
  removeCall: function() {},
  showGroupDetails: function() {},
  hideGroupDetails: function() {},
  isGroupDetailsShown: function() {},
  markCallsAsEnded: function() {},
  setGroupDetailsHeader: function() {}
};
