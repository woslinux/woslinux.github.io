'use strict';

/* exported MockCache */

var MockCache = {
  active: false,
  enabled: false,
  setFirstChunk(content) {

  },
  hasContact: function(uuid) {

  },
  hasFavorite: function(uuid) {

  },
  getContact: function(uuid) {

  },
  getFavorite: function(uuid) {

  },
  get headers() {
    return {};
  },
  verify: function() {

  },
  cleanup: function() {

  },
  evict: function() {

  },
  maybeEvict: function() {

  }
};
