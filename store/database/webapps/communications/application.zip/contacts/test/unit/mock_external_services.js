/* exported MockExtServices */
'use strict';

var MockExtServices = {
  importGmail: function() {},
  importLive: function() {}
};
