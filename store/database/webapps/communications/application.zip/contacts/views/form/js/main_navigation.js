/* global navigationStack */
/* exported MainNavigation */

(function(exports) {
  'use strict';
  exports.MainNavigation = new navigationStack('view-contact-form');
}(window));
