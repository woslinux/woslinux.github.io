'use strict';
/* exported MockSdManager */

var MockSdManager = {
  available: function() { return true; },
  checkSDButton: function() {},
  importContacts: function() {}
};
