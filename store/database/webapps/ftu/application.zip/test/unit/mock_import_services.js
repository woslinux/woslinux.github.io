'use strict';
/* exported MockImportIntegration */

var MockImportIntegration = {
  checkImport: function() {},
  init: function() {}
};
