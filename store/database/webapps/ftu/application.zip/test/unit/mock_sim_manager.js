'use strict';
/* exported MockSimManager */

var MockSimManager = {

  handleCardState: function() {},
  checkSIMButton: function() {},
  available: function() {},
  init: function() {}
};
