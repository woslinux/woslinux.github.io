'use strict';

/* exported Mockutils */

var Mockutils = {
  overlay: {
    show: function() {
      return {
        update: function() {}
      };
    },
    showMenu: function() {},
    hide: function() {}
  }
};
