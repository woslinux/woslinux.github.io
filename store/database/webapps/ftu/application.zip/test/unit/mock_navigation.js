/* exported MockNavigation */

'use strict';

var MockNavigation = {
  init: function() {},
};
