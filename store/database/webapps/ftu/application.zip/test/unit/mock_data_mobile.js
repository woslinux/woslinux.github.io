'use strict';
/* exported MockDataMobile */

var MockDataMobile = {
  init: function() {},
  setStatus: function(s) { this.status = s;},
  getStatus: function() {
    return status;
  },
  removeSVStatusObserver: function() {}
};
