/* exported MockOperatorVariant */

'use strict';

var MockOperatorVariant = {
  setSIMOnFirstBootState: function() {}
};
