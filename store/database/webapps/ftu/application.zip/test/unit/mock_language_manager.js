/* exported MockLanguageManager */
'use strict';

var MockLanguageManager = {
  init: function() {},
};
