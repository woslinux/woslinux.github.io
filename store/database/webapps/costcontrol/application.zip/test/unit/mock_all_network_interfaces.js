/* exported MockAllNetworkInterfaces */
'use strict';
var WifiInterfaceType = 0;
var MobileInterfaceType = 1;

var MockAllNetworkInterfaces = [
  {'type': WifiInterfaceType, 'id': '0'},
  {'type': MobileInterfaceType, 'id': '8100075100210526976'},
  {'type': MobileInterfaceType, 'id': '1234575100210522938'},
  {'type': MobileInterfaceType, 'id': '1234575100210511223'}
];
