/* exported MockSettings  */
'use strict';

var MockSettings = function() {
  return {
    initialize: function() {},
    updateUI: function() {}
  };
};
