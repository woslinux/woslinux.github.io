'use strict';

/* exported MockCallHandler */

var MockCallHandler = {
  call: function() {}
};
