/* exported MockICEContacts */

'use strict';

var MockICEContacts = {
  isFromICEContact: function() {}
};
