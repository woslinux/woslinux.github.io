'use strict';

require('/shared/js/template.js');
require('/shared/test/unit/load_body_html_helper.js');
require('/shared/test/unit/mocks/mocks_helper.js');
require('/views/shared/test/unit/assets_helper.js');
require('/views/shared/test/unit/fixture_phones.js');
