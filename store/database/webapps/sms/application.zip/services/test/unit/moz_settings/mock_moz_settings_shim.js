/*exported MockMozSettingsShim */
'use strict';

var MockMozSettingsShim = {
  set: () => {}
};
