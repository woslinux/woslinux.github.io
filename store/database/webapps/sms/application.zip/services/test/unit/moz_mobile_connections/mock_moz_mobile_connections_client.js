/* exported MockMozMobileConnectionsClient */

(function(exports) {
  'use strict';

  exports.MockMozMobileConnectionsClient = {
    init: () => {},
    switchMmsSimHandler: () => {}
  };
})(window);
