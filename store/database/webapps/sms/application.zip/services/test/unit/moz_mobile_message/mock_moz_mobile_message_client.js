/* exported MockMozMobileMessageClient */

(function(exports) {
  'use strict';

  exports.MockMozMobileMessageClient = {
    forApp: () => {}
  };
})(window);
