/* exported MockMessagingClient */
'use strict';

var MockMessagingClient = {
  init: () => {},
  sendSMS: () => {},
  sendMMS: () => {},
  resendMessage: () => {},
  retrieveMMS: () => {}
};
