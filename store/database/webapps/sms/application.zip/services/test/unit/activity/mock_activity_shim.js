/* exported MockActivityShim */

(function(exports) {
  'use strict';

  exports.MockActivityShim = {
    init: () => {}
  };
})(window);
