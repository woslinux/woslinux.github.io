/* exported bridge */

(function(exports) {
  'use strict';

  exports.Mockbridge = {
    client: () => {},
    service: () => {}
  };

  exports.MockstreamService = {};
  exports.MockstreamClient = {};
})(window);
