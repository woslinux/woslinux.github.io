/*exported MockSharedWorker */

'use strict';

function MockSharedWorker() {}
