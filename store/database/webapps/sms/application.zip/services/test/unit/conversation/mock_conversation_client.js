/* exported MockConversationClient */

(function(exports) {
  'use strict';

  exports.MockConversationClient = {
    init: () => {},
    getAllConversations: () => Promise.resolve()
  };
})(window);
