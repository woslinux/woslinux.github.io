/* global Startup */

(function() {
'use strict';

Startup.init();
})(self);
