/* exported MockNotify */
'use strict';

var MockNotify = {
  ringtone: function() {},
  vibrate: function() {}
};
