/*exported MockSystemMessageHandler */
'use strict';

var MockSystemMessageHandler = {
  init() {}
};
