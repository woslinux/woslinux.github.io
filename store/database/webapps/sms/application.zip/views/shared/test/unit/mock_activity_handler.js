/*exported MockActivityHandler */
'use strict';

var MockActivityHandler = {
  init() {}
};
