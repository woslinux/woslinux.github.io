/* exported MockApp */

(function(exports) {
  'use strict';

  exports.MockApp = {
    instanceId: 'app-instance-id',
    whenReady: () => Promise.resolve(),
    setReady: () => {}
  };
})(window);
