/*exported MockTimeHeaders */

'use strict';

var MockTimeHeaders = {
  init: function() {},
  startScheduler: function() {},
  stopScheduler: function() {},
  update: function() {},
  updateAll: function() {}
};
