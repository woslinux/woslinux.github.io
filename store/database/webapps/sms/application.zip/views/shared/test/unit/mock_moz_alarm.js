/* exported MockMozAlarms */
'use strict';

var MockMozAlarms = {
  add: function() {},
  remove: function() {}
};

