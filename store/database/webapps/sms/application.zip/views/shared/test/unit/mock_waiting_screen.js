/*exported MockWaitingScreen */

'use strict';

var MockWaitingScreen = {
  show: function() {},
  hide: function() {}
};
