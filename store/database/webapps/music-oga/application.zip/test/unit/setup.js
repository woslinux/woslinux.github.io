'use strict';

require('/shared/test/unit/mocks/mocks_helper.js');
