/* exported MockSearchView */
'use strict';

var MockSearchView = {
  init: function() {}
};
