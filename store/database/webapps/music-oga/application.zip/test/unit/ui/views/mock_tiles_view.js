/* exported MockTilesView */
'use strict';

var MockTilesView = {
  init: function() {},
  hideSearch: function() {}
};
