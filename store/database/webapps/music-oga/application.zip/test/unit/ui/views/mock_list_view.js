/* exported MockListView */
'use strict';

var MockListView = {
  init: function() {},
  activate: function() {},
  cancelEnumeration: function () {},
  update: function() {}
};
