/* exported MockSubListView */
'use strict';

var MockSubListView = {
  init: function() {},

  activate: function(option, data, index, keyRange, direction, callback) {
    callback();
  }
};
