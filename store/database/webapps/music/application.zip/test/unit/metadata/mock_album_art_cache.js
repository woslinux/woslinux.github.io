/* exported MockAlbumArtCache */
'use strict';


var MockAlbumArtCache = {
  getThumbnailURL: function() {
    return Promise.resolve();
  },
  getThumbnailBlob: function() {
    return Promise.resolve();
  }
};
