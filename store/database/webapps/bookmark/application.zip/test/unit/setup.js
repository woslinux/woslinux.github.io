'use strict';

/* global require */
require('/shared/test/unit/mocks/mocks_helper.js');
