/* global module */
module.exports = {
  settings: {
    'devtools.pseudolocalization.enabled': false,
    'language.current': 'en-US'
  }
};
