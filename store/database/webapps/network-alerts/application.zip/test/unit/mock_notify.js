/* exported MockNotify */
'use strict';

var MockNotify = {
  notify() {}
};
