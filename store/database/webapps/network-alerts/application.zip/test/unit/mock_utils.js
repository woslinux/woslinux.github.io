'use strict';

(function(exports) {

exports.MockUtils = {
  parseParams: function() {
    return {};
  }
};

})(window);
