/* global Attention */

'use strict';

(function() {
  Attention.init();
  Attention.render();
})();
