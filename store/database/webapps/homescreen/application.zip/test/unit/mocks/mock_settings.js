/* exported Settings */
'use strict';

(function(exports) {

  function Settings() {
    this.small = false;
    this.scrollSnapping = false;
    this.firstRun = false;
  }

  Settings.prototype = {
  };

  exports.Settings = Settings;

})(window);
