module.exports = {
  prefs: {
    'dom.webcomponents.enabled': true
  },
  settings: {
    'devtools.pseudolocalization.enabled': false,
    'language.current': 'en-US',
    'homescreen.manifestURL': 'app://homescreen.gaiamobile.org/manifest.webapp'
  }
};
